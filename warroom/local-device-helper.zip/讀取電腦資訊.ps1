﻿param([switch]$ExportOnly, [int]$Port = 17621, [string]$PairingCode = '')
$ErrorActionPreference = 'Stop'

function Get-CurrentDeviceInfo {
    $addresses = @()
    foreach ($adapter in [System.Net.NetworkInformation.NetworkInterface]::GetAllNetworkInterfaces()) {
        if ($adapter.OperationalStatus -ne [System.Net.NetworkInformation.OperationalStatus]::Up) { continue }
        foreach ($address in $adapter.GetIPProperties().UnicastAddresses) {
            if ($address.Address.AddressFamily -ne [System.Net.Sockets.AddressFamily]::InterNetwork) { continue }
            $ip = $address.Address.ToString()
            if ($ip -notmatch '^(10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)') { continue }
            $addresses += [ordered]@{ ip = $ip; adapter = $adapter.Name; type = $adapter.NetworkInterfaceType.ToString() }
        }
    }
    $osName = 'Windows'
    try { $osName = (Get-CimInstance Win32_OperatingSystem).Caption } catch {}
    return [ordered]@{
        schema = 'hsh-local-device-v1'
        computerName = [Environment]::MachineName
        os = $osName
        collectedAt = [DateTime]::UtcNow.ToString('o')
        interfaces = @($addresses)
    }
}

$exportPath = Join-Path $PSScriptRoot '本機資訊.json'
Get-CurrentDeviceInfo | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $exportPath -Encoding UTF8
if ($ExportOnly) { Write-Host "已匯出：$exportPath"; exit }
if (-not $PairingCode) {
    $randomBytes = New-Object byte[] 32
    $random = [System.Security.Cryptography.RandomNumberGenerator]::Create()
    try { $random.GetBytes($randomBytes) } finally { $random.Dispose() }
    $PairingCode = ([BitConverter]::ToString($randomBytes)).Replace('-', '').ToLowerInvariant()
}
if ($PairingCode -notmatch '^[a-f0-9]{64}$') { throw '配對碼格式錯誤。' }

function Test-AllowedOrigin([string]$Origin) {
    try {
        $parsed = [Uri]$Origin
        return $parsed.Scheme -eq 'https' -and $parsed.Authority -eq $parsed.Host -and $parsed.AbsolutePath -eq '/' -and -not $parsed.Query -and -not $parsed.Fragment -and (
            $parsed.Host -eq 'a-a2222370.vercel.app' -or $parsed.Host -eq 'script.google.com' -or $parsed.Host.EndsWith('.googleusercontent.com')
        )
    } catch { return $false }
}

$listener = [System.Net.Sockets.TcpListener]::new([System.Net.IPAddress]::Loopback, $Port)
try {
    $listener.Start()
    Write-Host '本機電腦資訊助手已啟動。只接受這台電腦的連線，不需要管理員權限。'
    Write-Host '在系統按「讀取本機 IP 與電腦名稱」，貼上以下配對碼：'
    Write-Host $PairingCode -ForegroundColor Cyan
    Write-Host '請保持這個視窗開啟；關閉視窗或按 Ctrl+C 即停止服務。'
    Write-Host "無法連線時可使用「匯入本機資訊」，檔案位置：$exportPath"
    while ($true) {
        $client = $listener.AcceptTcpClient()
        try {
            $client.ReceiveTimeout = 3000
            $client.SendTimeout = 3000
            $stream = $client.GetStream()
            $reader = [System.IO.StreamReader]::new($stream, [System.Text.Encoding]::ASCII, $false, 1024, $true)
            # 只讀取最多 8 KiB 的標頭，且每行有界；不接受 request body 或可執行指令。
            $header = ''; $line = ''; $total = 0
            while ($true) {
                $value = $reader.Read()
                if ($value -lt 0) { throw '連線提前結束。' }
                $total++
                if ($total -gt 8192) { throw '標頭過長。' }
                $header += [char]$value
                if ($header.EndsWith("`r`n`r`n")) { break }
            }
            $lines = $header -split "`r`n"
            $request = $lines[0] -split ' '
            $headers = @{}
            foreach ($line in $lines[1..($lines.Length - 1)]) {
                if (-not $line) { continue }
                $parts = $line -split ':', 2
                if ($parts.Length -ne 2 -or $headers.ContainsKey($parts[0].Trim().ToLowerInvariant())) { throw '標頭格式錯誤。' }
                $headers[$parts[0].Trim().ToLowerInvariant()] = $parts[1].Trim()
            }
            $origin = [string]$headers['origin']
            $status = '403 Forbidden'; $body = '{"error":"不允許此來源或配對碼錯誤"}'
            $cors = ''
            $validHost = $headers['host'] -eq "127.0.0.1:$Port"
            if ($validHost -and (Test-AllowedOrigin $origin)) {
                $cors = "Access-Control-Allow-Origin: $origin`r`nVary: Origin`r`nAccess-Control-Allow-Methods: GET, OPTIONS`r`nAccess-Control-Allow-Headers: Authorization`r`nAccess-Control-Allow-Private-Network: true`r`n"
                if ($request[1] -ne '/device-info') { $status = '404 Not Found'; $body = '{"error":"找不到此頁"}' }
                elseif ($request[0] -eq 'OPTIONS') {
                    if ($headers['access-control-request-method'] -eq 'GET' -and $headers['access-control-request-headers'] -eq 'authorization') {
                        $status = '204 No Content'; $body = ''
                    }
                }
                elseif ($request[0] -eq 'GET' -and $headers['authorization'] -ceq ('Bearer ' + $PairingCode)) {
                    $status = '200 OK'; $body = Get-CurrentDeviceInfo | ConvertTo-Json -Depth 5 -Compress
                }
            }
            $bodyBytes = [System.Text.Encoding]::UTF8.GetBytes($body)
            $responseHeader = "HTTP/1.1 $status`r`nContent-Type: application/json; charset=utf-8`r`nCache-Control: no-store`r`nX-Content-Type-Options: nosniff`r`nConnection: close`r`n$($cors)Content-Length: $($bodyBytes.Length)`r`n`r`n"
            $headerBytes = [System.Text.Encoding]::ASCII.GetBytes($responseHeader)
            $stream.Write($headerBytes, 0, $headerBytes.Length)
            if ($bodyBytes.Length) { $stream.Write($bodyBytes, 0, $bodyBytes.Length) }
        } catch {
            # 不回顯配對碼、請求標頭或網頁輸入內容。
        } finally { if ($reader) { $reader.Dispose(); $reader = $null }; $client.Close() }
    }
} finally { $listener.Stop() }
